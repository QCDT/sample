<template>
  <div id="app">
    <router-view name="navbar"/>
    <router-view/>
  </div>
</template>
<style lang="less">
</style>
