<template>
  <div>
    <h6>标签</h6>
    <goBack></goBack>
  </div>
</template>
<script>
import goBack from '@/components/tmp/zhanglan/go-1'
export default {
  props: {},
  components: { goBack },
  data () {
    return {}
  },
  methods: {},
  computed: {}
}
</script>
<style scoped lang='scss'>
</style>
