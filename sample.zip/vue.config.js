module.exports = {
  lintOnSave: false,
  devServer: {
    port: 8071, // 端口号
    https: false // 是否是https协议
    // hotOnly: false // 热加载
  }
}
